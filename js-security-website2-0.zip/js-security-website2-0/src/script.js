emailjs.init("pwB5GMiMzarHZAeiB");  // Replace with your public key

const fadeEls = document.querySelectorAll(".fade-in");

const reveal = () => fadeEls.forEach(el => {

  if (el.getBoundingClientRect().top < innerHeight - 100) el.classList.add("show");

});

addEventListener("scroll", reveal);

addEventListener("load", reveal);

const openBtn = document.getElementById("openQuote");

const popup = document.getElementById("quotePopup");

const closeBtn = document.querySelector(".close-btn");

openBtn.addEventListener("click", e => {

  e.preventDefault();

  popup.style.display = "flex";

});

closeBtn.addEventListener("click", () => popup.style.display = "none");

window.addEventListener("click", e => { if (e.target === popup) popup.style.display = "none"; });

document.getElementById("quoteForm").addEventListener("submit", function(e){

  e.preventDefault();

  emailjs.sendForm("service_k1qu2i3","template_51j63su",this)

    .then(()=>{

      alert("✅ Quote submitted!");

      this.reset();

      popup.style.display = "none";

    })

    .catch(err=>{

      console.error(err);

      alert("❌ Submission failed.");

    });

});

// Scroll-based animations using Intersection Observer

const sections = document.querySelectorAll("section");

const observer = new IntersectionObserver(entries => {

  entries.forEach(entry => {

    if (entry.isIntersecting) {

      entry.target.classList.add("show");

    }

  });

}, { threshold: 0.2 });

sections.forEach(section => {

  observer.observe(section);

});

// Active nav link highlighting

const navLinks = document.querySelectorAll("nav a");

window.addEventListener("scroll", () => {

  let current = "";

  sections.forEach(section => {

    const sectionTop = section.offsetTop - 100;

    if (scrollY >= sectionTop) {

      current = section.getAttribute("id");

    }

  });

  navLinks.forEach(link => {

    link.classList.remove("active");

    if (link.getAttribute("href") === `#${current}`) {

      link.classList.add("active");

    }

  });

});

// Observe each .service-card too

document.querySelectorAll('.service-card').forEach(card => observer.observe(card));

